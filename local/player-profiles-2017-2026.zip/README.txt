NFL Draft Archive: 2,569 players, 2017-2026.
Each filename is draft-year plus overall pick.
Current team and league status are a dated source snapshot, distinct from drafted team. Current-teams.json preserves membership/status evidence.
Measurements preserve source, event, unit and designation. Missing data is not zero.
College statistics retain provider labels and coverage; biography tables may be partial.
Benchmarks describe this archive: one observation per drafted player, positional samples, minimum 20 for ranking.
Timed/jump/bench reference groups use official combine results when available. Body sizes use reported measurements.
No unpublished private-workout results are inferred. Full source prose is excluded.
NFL careers: regular season, Year 1 = draft season, one row per season through the in-progress season (nfl-careers.json); careers/ holds position career-arc trends and player grids.
